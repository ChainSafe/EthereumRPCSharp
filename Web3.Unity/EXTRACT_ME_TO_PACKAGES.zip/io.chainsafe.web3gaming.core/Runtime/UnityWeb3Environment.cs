using ChainSafe.GamingWeb3.Environment;

namespace ChainSafe.GamingWeb3.Unity
{
  public class UnityWeb3Environment : IWeb3Environment
  {
    public IHttpClient HttpClient { get; } = new UnityHttpClient();
  }
}