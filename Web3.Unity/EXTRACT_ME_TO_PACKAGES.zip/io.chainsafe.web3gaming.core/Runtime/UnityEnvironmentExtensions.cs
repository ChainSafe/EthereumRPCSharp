using ChainSafe.GamingWeb3.Build;
using ChainSafe.GamingWeb3.Environment;
using Microsoft.Extensions.DependencyInjection;

namespace ChainSafe.GamingWeb3.Unity
{
  public static class UnityEnvironmentExtensions
  {
    public static void UseUnityEnvironment(this IWeb3ServiceCollection services)
    {
      services.AddSingleton<IWeb3Environment, UnityWeb3Environment>();
    }
  }
}