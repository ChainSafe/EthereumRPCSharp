using System.Threading.Tasks;
using ChainSafe.GamingWeb3.Environment;
using Newtonsoft.Json;
using UnityEngine;

namespace ChainSafe.GamingWeb3.Unity
{
  public class UnityHttpClient : IHttpClient
  {
    public async ValueTask<TResponse> Post<TRequest, TResponse>(string url, TRequest data)
    {
      Debug.LogError("Simulating post");

      return JsonConvert.DeserializeObject<TResponse>("1");
    }
  }
}